# Basic CRUD API

This project demonstrates a simple FastAPI application with CRUD operations using SQLAlchemy and Pydantic.
