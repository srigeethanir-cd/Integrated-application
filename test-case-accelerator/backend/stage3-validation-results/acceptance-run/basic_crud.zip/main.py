from fastapi import FastAPI
from app.routers import items

app = FastAPI(title="Basic CRUD API")

app.include_router(items.router)
