# JWT Authentication API

This project demonstrates user registration, login, JWT token generation, password hashing, and protected routes using FastAPI.
